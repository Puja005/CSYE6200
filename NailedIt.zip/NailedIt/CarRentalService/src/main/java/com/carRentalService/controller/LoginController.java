package com.carRentalService.controller;

import com.carRentalService.CarRentalServiceApp;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

import static com.carRentalService.CarRentalServiceApp.loggedInUser;

public class LoginController {
    @FXML
    private TextField userName;
    @FXML
    private PasswordField password;
    @FXML
    private Label loginErrorMsg;
    @FXML
    protected void userLoginClick() throws IOException {

        verifyUserDetails();
    }

    private void verifyUserDetails() throws IOException {
        CarRentalServiceApp carRentalServiceApp=new CarRentalServiceApp();
        if(userName.getText().isEmpty() || password.getText().isEmpty())
            loginErrorMsg.setText("Please enter login credentials");
        else if(userName.getText().equals("admin") && password.getText().equals("admin"))
        {
            loginErrorMsg.setText("success");
            loggedInUser=userName.getText();
            carRentalServiceApp.updateScreen("adminUser-view.fxml");
        }
        else  if(userName.getText().equals("gaurav") && password.getText().equals("gaurav"))
        {
            loginErrorMsg.setText("success");
            loggedInUser=userName.getText();
            carRentalServiceApp.updateScreen("customer-search-booking.fxml");
        }else{
            loginErrorMsg.setText("Wrong User Name or Password");
        }

    }
}