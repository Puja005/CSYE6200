package com.carRentalService;

import com.carRentalService.model.BookingModel;
import com.carRentalService.model.CarModel;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;


public class CarRentalServiceApp extends Application {

    public static String loggedInUser;
    public static Map<String, CarModel> cars=new HashMap<>();
    public static List<CarModel> carList=new ArrayList<>();
    public static final List<String> carYearList = Arrays.asList(
                    "2015","2016","2017","2018","2019","2020","2021","2022","2023");

    public static HashMap<String,String> carMakeMap=new HashMap<>();
    static {
        carMakeMap.put("J","Jeep");
        carMakeMap.put("A","Acura");
    }
    public static Map<String, BookingModel> bookingMap=new HashMap<>();
    public static List<BookingModel> bookingList=new ArrayList<>();
    private static Stage stage;
    @Override
    public void start(Stage loginStage) throws IOException {
        stage=loginStage;
        loginStage.setResizable(false);
        FXMLLoader fxmlLoader = new FXMLLoader(CarRentalServiceApp.class.getResource("login-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 750, 400);
        stage.setTitle("CAR RENTAL SERVICE");
        stage.setScene(scene);
        stage.show();
    }

    public void updateScreen(String newStageText) throws IOException{
        Parent parentPane=FXMLLoader.load(CarRentalServiceApp.class.getResource(newStageText));
        stage.getScene().setRoot(parentPane);
    }
    public static void main(String[] args) {
        launch();
    }
}