package com.carRentalService.controller;

import com.carRentalService.model.BookingModel;
import com.carRentalService.model.CarModel;
import com.carRentalService.model.TableBookingModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.LocalDate;
import java.util.*;

import static com.carRentalService.CarRentalServiceApp.*;

public class CustomerNewBookingController extends CustomerController implements Initializable {

    @FXML
    private ComboBox<String> makeDropDown;

    @FXML
    private Label searchWarningLabel;

    @FXML
    private Label userNameLabel;

    @FXML
    private ComboBox<String> yearDropDown;

    @FXML
    private TableView tableView;


    @FXML
    private Button bookButton;

    @FXML
    private DatePicker dateFromPicker;

    @FXML
    private DatePicker dateToPicker;

    @FXML
    void searchButtonAction() {

        if (makeDropDown.getSelectionModel().isEmpty()) {
            searchWarningLabel.setText("Please Select Make");
            searchWarningLabel.setVisible(true);
        } else if (yearDropDown.getSelectionModel().isEmpty()) {
            searchWarningLabel.setText("Please Select Year");
            searchWarningLabel.setVisible(true);
        } else if (dateFromPicker.getValue() == null) {
            searchWarningLabel.setText("Please Select From Date");
            searchWarningLabel.setVisible(true);
        } else if (dateToPicker.getValue() == null) {
            searchWarningLabel.setText("Please Select to Date");
            searchWarningLabel.setVisible(true);
        }else if(dateFromPicker.getValue().isAfter(dateToPicker.getValue())){
            searchWarningLabel.setText("To Date should be after From Date");
            searchWarningLabel.setVisible(true);
        }
        else {
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
            bookButton.setVisible(false);

            String makeValue = makeDropDown.getSelectionModel().getSelectedItem();
            String yearValue = yearDropDown.getSelectionModel().getSelectedItem();
            LocalDate dateFrom = dateFromPicker.getValue();
            LocalDate dateTo = dateToPicker.getValue();
            List<CarModel> searchCarList = carList.stream().filter(booking -> booking.getCarMake().equals(makeValue) && booking.getCarYear().equals(yearValue)).toList();
            List<BookingModel> searchModelList = new ArrayList<>();
            for (CarModel carModel : searchCarList) {
                boolean canAdd = true;
                for (BookingModel bookingModel : bookingList) {
                    if (bookingModel.getPlateNumber().equals(carModel.getPlateNumber())
                            && (((dateFrom.isAfter(bookingModel.getDateFrom())|| dateFrom.isEqual(bookingModel.getDateFrom())) &&
                            (dateFrom.isBefore(bookingModel.getDateTo()) || dateFrom.isEqual(bookingModel.getDateTo())))
                            || ((dateTo.isAfter(bookingModel.getDateFrom()) || dateTo.isEqual(bookingModel.getDateFrom()))
                            && (dateTo.isBefore(bookingModel.getDateTo()) || dateTo.isEqual(bookingModel.getDateTo())))))
                        canAdd = false;
                }
                if (canAdd)
                    searchModelList.add(new BookingModel(carModel, "", dateFrom, dateTo));
            }

            if (searchModelList.isEmpty()) {
                searchWarningLabel.setText("No Vehicles found for current selection");
                searchWarningLabel.setVisible(true);
            } else {
                searchWarningLabel.setVisible(false);
                bookButton.setVisible(true);
                tableView.setVisible(true);
                tableView.getColumns().clear();
                TableColumn carMake = new TableColumn("Car Make");
                TableColumn carYear = new TableColumn("Car Year");
                TableColumn carColor = new TableColumn("Car Color");

                List<TableBookingModel> tableBookingModelList = new ArrayList<>();
                tableView.getColumns().addAll(carYear, carMake, carColor);
                for (BookingModel bookingModel : searchModelList) {
                    tableBookingModelList.add(new TableBookingModel(bookingModel.getCarMake(), bookingModel.getCarYear(), bookingModel.getCarColor(), bookingModel.getPlateNumber()));
                }
                ObservableList<TableBookingModel> data = FXCollections.observableArrayList(tableBookingModelList);

                carMake.setCellValueFactory(
                        new PropertyValueFactory<TableBookingModel, String>("carMake")
                );
                carYear.setCellValueFactory(
                        new PropertyValueFactory<TableBookingModel, String>("carYear")
                );
                carColor.setCellValueFactory(
                        new PropertyValueFactory<TableBookingModel, String>("carColor")
                );


                tableView.setItems(data);
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        bookButton.setVisible(false);
        userNameLabel.setText(loggedInUser.toUpperCase(Locale.ROOT));
        searchWarningLabel.setVisible(false);
        List<String> carMakeList = new ArrayList<>(carMakeMap.values().stream().toList());
        Collections.sort(carMakeList);
        makeDropDown.getItems().addAll(carMakeList);
        yearDropDown.getItems().addAll(carYearList);
        tableView.setVisible(false);

    }

    @FXML
    void bookButtonClick() {
        TableBookingModel booking = (TableBookingModel) tableView.getSelectionModel().getSelectedItem();
        String bookingId = UUID.randomUUID().toString();
        searchWarningLabel.setVisible(true);
        CarModel carModel = cars.get(booking.getPlateNumber().get());
        BookingModel bookingModel = new BookingModel(carModel, bookingId, dateFromPicker.getValue(), dateToPicker.getValue());
        bookingMap.put(bookingId, bookingModel);
        bookingList.add(bookingModel);
        System.out.println("booking id : " + bookingId);
        searchWarningLabel.setText("Booking id: " + bookingId);
        tableView.setVisible(false);
        bookButton.setVisible(false);
    }
}
