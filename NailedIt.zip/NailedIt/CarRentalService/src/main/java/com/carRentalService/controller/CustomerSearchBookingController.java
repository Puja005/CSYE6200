package com.carRentalService.controller;

import com.carRentalService.model.BookingModel;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import static com.carRentalService.CarRentalServiceApp.bookingMap;
import static com.carRentalService.CarRentalServiceApp.loggedInUser;

public class CustomerSearchBookingController extends CustomerController implements Initializable {

    @FXML
    private Label bookingIdData;

    @FXML
    private Label carColorData;

    @FXML
    private Label carMakeData;

    @FXML
    private Label carYearData;

    @FXML
    private Label dateFromData;

    @FXML
    private Label dateToData;

    @FXML
    private Label carMakeLabel;

    @FXML
    private Label carYearLabel;

    @FXML
    private Label plateNumberLabel;

    @FXML
    private Label carColorLabel;

    @FXML
    private Label plateNumberData;

    @FXML
    private Label dateToLabel;

    @FXML
    private Label dateFromLabel;

    @FXML
    private TextField searchTextBox;

    @FXML
    private Label searchWarningLabel;

    @FXML
    private Label userNameLabel;

    @FXML
    private Label bookingIdLabel;

    @FXML
    void searchButtonAction() {
        if(searchTextBox.getText().isEmpty())
        {
            toggleResultPanel(false);
            searchWarningLabel.setText("Enter Id to Search");
        }else{

            if(bookingMap.containsKey(searchTextBox.getText()))
            {
                BookingModel bookingModel=bookingMap.get(searchTextBox.getText());
                toggleResultPanel(true);
                bookingIdData.setText(bookingModel.getBookingId());
                plateNumberData.setText(bookingModel.getPlateNumber());
                carMakeData.setText(bookingModel.getCarMake());
                carYearData.setText(bookingModel.getCarYear());
                carColorData.setText(bookingModel.getCarColor());
                dateToData.setText(bookingModel.getDateTo().toString());
                dateFromData.setText(bookingModel.getDateFrom().toString());
            }else{
                toggleResultPanel(false);
                searchWarningLabel.setText("No Data Found!!");
            }
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        userNameLabel.setText(loggedInUser.toUpperCase(Locale.ROOT));
        toggleResultPanel(false);
        searchWarningLabel.setVisible(false);
    }

    void toggleResultPanel(boolean toggle) {
        carColorData.setVisible(toggle);
        carMakeData.setVisible(toggle);
        carMakeLabel.setVisible(toggle);
        carYearData.setVisible(toggle);
        carYearLabel.setVisible(toggle);
        plateNumberData.setVisible(toggle);
        plateNumberLabel.setVisible(toggle);
        carColorLabel.setVisible(toggle);
        searchWarningLabel.setVisible(!toggle);
        dateFromData.setVisible(toggle);
        dateToData.setVisible(toggle);
        dateFromLabel.setVisible(toggle);
        dateToLabel.setVisible(toggle);
        bookingIdData.setVisible(toggle);
        bookingIdLabel.setVisible(toggle);
    }
}
