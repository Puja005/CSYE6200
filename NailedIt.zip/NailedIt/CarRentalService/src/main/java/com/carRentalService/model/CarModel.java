package com.carRentalService.model;



public class CarModel {
    private String plateNumber;
    private String carMake;
    private String carYear;
    private String carColor;
    
	public String getPlateNumber() {
		return plateNumber;
	}
	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}
	public String getCarMake() {
		return carMake;
	}
	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}
	public String getCarYear() {
		return carYear;
	}
	public void setCarYear(String carYear) {
		this.carYear = carYear;
	}
	public String getCarColor() {
		return carColor;
	}
	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}
	public CarModel(String plateNumber, String carMake, String carYear, String carColor) {
		super();
		this.plateNumber = plateNumber;
		this.carMake = carMake;
		this.carYear = carYear;
		this.carColor = carColor;
	}
	public CarModel() {
		super();
	}
    
    
}
