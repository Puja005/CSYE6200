package com.carRentalService.controller;

import com.carRentalService.CarRentalServiceApp;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.IOException;

public class AdminController {

    CarRentalServiceApp carRentalServiceApp=new CarRentalServiceApp();
    public void viewCarButtonClick() throws IOException {
        carRentalServiceApp.updateScreen("adminUser-view.fxml");
    }
    public void addCarButtonClick() throws IOException {
        carRentalServiceApp.updateScreen("adminUser-add.fxml");
    }
    public void addNewBrandButtonClick() throws IOException {
        carRentalServiceApp.updateScreen("adminUser-addNewBrand.fxml");
    }
    public void logOutButtonClick() throws IOException{
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure that you want to Exit");
        alert.setTitle("LogOut");
        alert.setHeaderText("You are about to Logout");
        if(alert.showAndWait().get()== ButtonType.OK){
            CarRentalServiceApp.loggedInUser="";
            carRentalServiceApp.updateScreen("login-view.fxml");
        }
    }
}
