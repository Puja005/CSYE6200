package com.carRentalService.controller;

import com.carRentalService.model.CarModel;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.*;

import static com.carRentalService.CarRentalServiceApp.*;


public class AdminAddCarController extends AdminController implements Initializable {

    @FXML
    private Label warningAddCarLabel;


    @FXML
    private TextField carColorText;

    @FXML
    private ComboBox<String> carMakeCombo;


    @FXML
    private ComboBox<String> carYearCombo;

    @FXML
    private TextField plateNumberText;

    @FXML
    void saveCarButtonAction() {
        warningAddCarLabel.setVisible(true);
        if(plateNumberText.getText().isEmpty() ) {
            warningAddCarLabel.setText("Enter Plate Number");
        }else if(carMakeCombo.getSelectionModel().isEmpty()){
            warningAddCarLabel.setText("Please select Make");
        }else if( carYearCombo.getSelectionModel().isEmpty()){
            warningAddCarLabel.setText("Please select year");
        }else if( carColorText.getText().isEmpty()) {
            warningAddCarLabel.setText("Enter Color");
        }else {
            if (cars.containsKey(plateNumberText.getText()))
                warningAddCarLabel.setText("Car Already Exists!!!");

            else {
                CarModel car=new CarModel(plateNumberText.getText(), carMakeCombo.getValue(), carYearCombo.getValue(), carColorText.getText());
                cars.put(plateNumberText.getText(),car );
                carList.add(car);
                warningAddCarLabel.setText("Car saved successfully");
            }

        }
    }
    @FXML
    void resetButtonClick(){
        warningAddCarLabel.setVisible(false);
        plateNumberText.setText("");
        carMakeCombo.valueProperty().set("");
        carYearCombo.valueProperty().set("");
        carColorText.setText("");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<String> carMakeComboList=carMakeCombo.getItems();
        List<String> carMakeList=new ArrayList<>(carMakeMap.values().stream().toList());
        Collections.sort(carMakeList);
        Iterator<String> carMakeModelIterator=carMakeList.iterator();
        while(carMakeModelIterator.hasNext()){
            carMakeComboList.add(carMakeModelIterator.next());
        }
   carYearCombo.getItems().addAll(carYearList);
    }
}
