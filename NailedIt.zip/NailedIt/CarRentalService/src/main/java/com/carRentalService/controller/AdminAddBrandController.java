package com.carRentalService.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import lombok.extern.slf4j.Slf4j;

import static com.carRentalService.CarRentalServiceApp.carMakeMap;


public class AdminAddBrandController extends AdminController{

    @FXML
    private TextField brandNameText;

    @FXML
    private TextField brandCodeText;

    @FXML
    private Label warningAddBrandLabel;



    @FXML
    void resetBrandButtonClick() {
        warningAddBrandLabel.setVisible(false);
        brandNameText.setText("");
        brandCodeText.setText("");
    }

    @FXML
    void saveBrandButtonAction() {
        warningAddBrandLabel.setVisible(true);
        if (brandNameText.getText().isEmpty())
            warningAddBrandLabel.setText("Please Enter Brand Name");
        else if(brandCodeText.getText().isEmpty())
            warningAddBrandLabel.setText("Please Enter Brand Code");
        else{
            if(carMakeMap.containsKey(brandCodeText.getText()))
                warningAddBrandLabel.setText("Brand Already Exists");
            else{
                carMakeMap.put(brandCodeText.getText(),brandNameText.getText());
                warningAddBrandLabel.setText("Brand Saved!!!");
            }
        }

    }

}
