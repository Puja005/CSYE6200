package com.carRentalService.controller;

import com.carRentalService.model.CarModel;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

import static com.carRentalService.CarRentalServiceApp.carList;
import static com.carRentalService.CarRentalServiceApp.cars;

public class AdminUserViewController extends AdminController implements Initializable {




    @FXML
    private Label carColorData;

    @FXML
    private Label carColorLabel;

    @FXML
    private Label carMakeData;

    @FXML
    private Label carMakeLabel;

    @FXML
    private Label carYearData;

    @FXML
    private Label carYearLabel;



    @FXML
    private Label plateNumberData;

    @FXML
    private Label plateNumberLabel;

    @FXML
    private Label searchWarningLabel;
    @FXML
    private TextField searchTextBox;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(cars.isEmpty())
        {
            CarModel car=new CarModel("123","Jeep","2015","Red");
            cars.put("123",car);
            carList.add(car);
        }
        toggleResultPanel(false);
        searchWarningLabel.setVisible(false);
    }
    public void searchButtonAction(){
        if(searchTextBox.getText().isEmpty())
        {
            searchWarningLabel.setVisible(true);
            searchWarningLabel.setText("Please Enter Plate Number");
        }else{
        CarModel carModelResult=cars.get(searchTextBox.getText());
        if(carModelResult!=null) {
            toggleResultPanel(true);
            plateNumberData.setText(carModelResult.getPlateNumber());
            carMakeData.setText(carModelResult.getCarMake());
            carYearData.setText(carModelResult.getCarYear());
            carColorData.setText(carModelResult.getCarColor());
        }else{
            toggleResultPanel(false);
            searchWarningLabel.setText("No Data Found!!");
        }}
    }
    void toggleResultPanel(boolean toggle){
        carColorData.setVisible(toggle);
        carMakeData.setVisible(toggle);
        carMakeLabel.setVisible(toggle);
        carYearData.setVisible(toggle);
        carYearLabel.setVisible(toggle);
        plateNumberData.setVisible(toggle);
        plateNumberLabel.setVisible(toggle);
        carColorLabel.setVisible(toggle);
        searchWarningLabel.setVisible(!toggle);
    }
}
