package com.carRentalService.controller;

import com.carRentalService.CarRentalServiceApp;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.IOException;

public class CustomerController {

    CarRentalServiceApp carRentalServiceApp=new CarRentalServiceApp();
    public void searchBookingButtonClick() throws IOException {
        carRentalServiceApp.updateScreen("customer-search-booking.fxml");
    }
    public void addNewBookingButtonClick() throws IOException {
        carRentalServiceApp.updateScreen("customer-new-booking.fxml");
    }
    public void logOutButtonClick() throws IOException{
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure that you want to Exit");
        alert.setTitle("LogOut");
        alert.setHeaderText("You are about to Logout");
        if(alert.showAndWait().get()== ButtonType.OK){
            CarRentalServiceApp.loggedInUser="";
            carRentalServiceApp.updateScreen("login-view.fxml");
        }
    }
}
