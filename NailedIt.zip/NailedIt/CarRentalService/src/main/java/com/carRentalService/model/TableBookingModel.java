/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carRentalService.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.CheckBox;
import lombok.Data;

@Data
public class TableBookingModel {


    private SimpleStringProperty carMake;
    private SimpleStringProperty carYear;
    private SimpleStringProperty carColor;
    private SimpleStringProperty plateNumber;
/*
    private CheckBox checkbox;
*/

    public TableBookingModel(String carMake, String carYear, String carColor,String plateNumber) {
        this.carMake = new SimpleStringProperty(carMake);
        this.carYear = new SimpleStringProperty(carYear);
        this.carColor = new SimpleStringProperty(carColor);
        this.plateNumber=new SimpleStringProperty(plateNumber);
/*
        this.checkbox = new CheckBox();
*/
    }

    public String getCarMake() {
        return carMake.get();
    }

    public void setCarMake(String carMake) {
        this.carMake.set(carMake);
    }

    public String getCarYear() {
        return carYear.get();
    }

    public void setCarYear(String carYear) {
        this.carYear.set(carYear);
    }

    public String getCarColor() {
        return carColor.get();
    }

    public void setCarColor(String carColor) {
        this.carColor.set(carColor);
    }

	public SimpleStringProperty getPlateNumber() {
		return plateNumber;
	}

	public void setPlateNumber(SimpleStringProperty plateNumber) {
		this.plateNumber = plateNumber;
	}

/*

    public CheckBox getCheckbox() {
        return checkbox;
    }

    public void setCheckBox(CheckBox checkbox) {
        this.checkbox = checkbox;
    }
*/


}
