package com.carRentalService.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
public class BookingModel extends CarModel {
    private String bookingId;

    private LocalDate dateFrom;
    private LocalDate dateTo;

    public BookingModel(CarModel carModel, String bookingId, LocalDate dateFrom,LocalDate dateTo){
        this.setPlateNumber(carModel.getPlateNumber());
        this.setCarMake(carModel.getCarMake());
        this.setCarYear(carModel.getCarYear());
        this.setCarColor(carModel.getCarColor());
        this.bookingId=bookingId;
        this.dateFrom=dateFrom;
        this.dateTo=dateTo;
    }

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public LocalDate getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(LocalDate dateFrom) {
		this.dateFrom = dateFrom;
	}

	public LocalDate getDateTo() {
		return dateTo;
	}

	public void setDateTo(LocalDate dateTo) {
		this.dateTo = dateTo;
	}

}
